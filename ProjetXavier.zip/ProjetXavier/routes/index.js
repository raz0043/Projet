const express = require("express");
const router = express.Router();
const ResultatScan = require("../models/ResultatScan");
const { exec } = require("child_process");
const cheminNmap = `"C:/Program Files (x86)/Nmap/nmap.exe"`;

// Page d'accueil
router.get("/", (req, res) => {
  res.render("index");
});

// Formulaire pour la requette de l'utilisateur
router.get("/requete", (req, res) => {
  res.render("requete");
});

// Envoie du formulaire
router.post("/requete", (req, res) => {
  const options = req.body.options;

  // nmap
  exec(`${cheminNmap} ${options}`, (error, stdout, stderr) => {
    if (error) {
      console.error(
        `Erreur sur la commande que tu viens de taper: ${error.message}`
      );
      res.redirect("/requete");
      return;
    }

    // Récupère le résultat du scan
    const resultat = stdout.trim();

    const resultatScan = new ResultatScan({
      options: options,
      resultat: resultat,
    });

    resultatScan
      .save()
      .then(() => {
        res.redirect("/historique");
      })
      .catch((error) => {
        console.error(error);
        res.redirect("/requete");
      });
  });
});

// Historique
router.get("/historique", async (req, res) => {
  try {
    const resultatsScan = await ResultatScan.find().sort({ horodatage: -1 });
    res.render("historique", { resultatsScan: resultatsScan });
  } catch (error) {
    console.error(error);
    res.redirect("/");
  }
});

// Détails pour l'historique
router.get("/details/:id", async (req, res) => {
  try {
    const resultatScan = await ResultatScan.findById(req.params.id);
    res.render("details", { resultatScan: resultatScan });
  } catch (error) {
    console.error(error);
    res.redirect("/historique");
  }
});

module.exports = router;
