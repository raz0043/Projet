const mongoose = require("mongoose");
mongoose
  .connect("mongodb://127.0.0.1:27017/DBXavier", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => console.log("Connecté à MongoDB"))
  .catch((err) => console.error("Échec de la connexion à MongoDB", err));

const express = require("express");
const bodyParser = require("body-parser");
const app = express();
const port = 3000;

app.set("view engine", "ejs");
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("public"));

const indexRoute = require("./routes/index");
app.use("/", indexRoute);

// Pour demarrer le server
app.listen(port, () => {
  console.log(`Serveur en écoute sur le port ${port}`);
});
