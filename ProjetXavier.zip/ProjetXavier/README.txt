Créer une interface web pour l'outil CLI nmap.

    En utilisant la documentation officielle ([https://nmap.org/book/man-briefoptions.html]), implémentez au moins une option de scan (par exemple -sS, -sV, etc.) et au moins 3 options (par exemple --max-retries, --host-timeout, etc.) ;
    Vous devez stocker les résultats de chaque requête dans une base de données ;
    Vous devez utiliser MongoDB comme moteur de base de données et Mongoose.js ;
    Votre interface doit présenter au moins 3 pages :
        l'interface de requête (un formulaire) ;
        la page d'historique (une liste de toutes les requêtes passées) ;
        les détails d'une requête passée, montrant la sortie d'un nmap pour le résultat d'une requête précédente stockée dans la base de données, mais aussi toutes les options utilisées pour cette requête dans le formulaire de requête ;
    Vous pouvez utiliser n'importe quel cadre ou code source des leçons ;
    Vous pouvez réaliser une API synchrone ou asynchrone ;
    Mais dans les deux cas, vous devrez traiter toutes les requêtes indépendamment du frontend (c'est-à-dire que si l'utilisateur quitte la page de requête, la requête ne doit pas être interrompue du côté du backend, et toutes les informations doivent être stockées correctement dans la base de données) ;
    BONUS : gérer les utilisateurs (inscription/signature) et gérer l'accès aux requêtes en fonction des utilisateurs (c'est-à-dire qu'un utilisateur ne peut accéder qu'à ses propres requêtes).

Notation et livraison

    qualité du code :
        votre code doit être lité et correctement formaté à l'aide des outils vus pendant les cours ;
        toutes les bonnes pratiques vues pendant les cours ;
    vous livrerez votre code dans un fichier zip téléchargé sur Pepal et sur GitHub (le lien doit être dans un fichier README.md à la racine du projet) sans fichiers ignorés/temporaires/sensibles ;
    toute fonctionnalité manquante ou code incorrect diminuera votre score final ;
    vous avez jusqu'au 21 mai 2023 11:59:59 PM pour télécharger votre livraison.

Pour vous aider, voici un extrait de la documentation du site officiel de NodeJS : [https://nodejs.org/dist/latest-v19.x/docs/api/child_process.html#child_processspawncommand-args-options]

-------------------------------------------------------------------------------
Create a web interface for the CLI tool nmap.

    Using the official documentation ([https://nmap.org/book/man-briefoptions.html]), implement at least one scan option (e.g -sS, -sV, etc.) and at least 3 options (e.g --max-retries, --host-timeout, etc.);
    You have to store the results of each query in a database;
    You have to use MongoDB as your database engine and Mongoose.js;
    Your interface should present at least 3 pages:
        the query interface (a form);
        the history page (a list of all past queries);
        the details of a past query, showing the output of a nmap for a previous query’s result stored in the database, but also all the option used for that query in the query form;
    You can use any framework or source code from the lessons;
    You can either do a synchronous API, or an asynchronous one;
    But in both case, you will have to process all queries regardless of the frontend (i.e if the user leaves the query page, the query should not be aborted on the backend side, as well as all information should be store properly in the database);
    BONUS: handle users (sign-up/sign-in) and handle access to queries according to users (i.e a user can only access to his own queries).

Scoring and delivery

    code quality:
        your code must be linted and properly formatted using tools seen during the lessons;
        all best practice seen during the lessons;
    you will deliver your code in a zip file uploaded on Pepal and on GitHub (link should be in a README.md file at the root of the project) without ignored/temporary/sensitive files;
    any missing feature or improper code will diminish your final score;
    you have until May 21st, 2023 11:59:59 PM to upload your delivery.

To help you, here is a piece of documentation from NodeJS official website: [https://nodejs.org/dist/latest-v19.x/docs/api/child_process.html#child_processspawncommand-args-options]