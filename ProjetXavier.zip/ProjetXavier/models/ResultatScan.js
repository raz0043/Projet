const mongoose = require("mongoose");

const schemaResultatScan = new mongoose.Schema({
  options: String,
  resultat: String,
  horodatage: { type: Date, default: Date.now },
});

const ResultatScan = mongoose.model("ResultatScan", schemaResultatScan);

module.exports = ResultatScan;